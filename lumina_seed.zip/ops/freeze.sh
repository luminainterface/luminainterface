
#!/usr/bin/env bash
set -e
echo "Freezing Lumina stack..."
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
ARCHIVE=lumina_bundle_$TIMESTAMP.tar.gz
docker compose down
docker save $(docker compose config --services | xargs -I{} docker compose images -q {} ) -o images.tar
tar -czf $ARCHIVE images.tar qdrant_snapshot/ configs/
echo "Created $ARCHIVE"
