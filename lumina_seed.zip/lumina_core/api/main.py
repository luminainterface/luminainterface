
from fastapi import FastAPI, Body

app = FastAPI(title="Lumina Hub API", version="0.1.0")

@app.get("/health")
async def health():
    return {"status": "ok"}

@app.post("/chat")
async def chat(message: str = Body(..., embed=True)):
    # placeholder: echo style; later this will proxy to LLM engine
    return {"reply": f"Echo: {message}"}
