
# Lumina Seed Scaffold

This is the minimal starting point for your self-growing, modular Lumina stack.

## Included

* **hub-api** – FastAPI gateway (`/health`, `/chat`).
* **vector-db** – Qdrant vector store.
* **llm-engine** – Placeholder for local llama.cpp server.
* **scheduler** – Placeholder image; swap in Prefect/Temporal later.
* **freeze.sh** – Snapshot script (creates tarball of images + data volumes).

## Quickstart

```bash
docker compose up --build
curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" -d '{"message":"Hello"}'
```

## Next

1. Mount your GGUF model into `llm-engine` and implement proxy logic inside `hub-api`.
2. Add new modules under `modules/<name>` with their own Dockerfile and manifest.
3. Flesh out the scheduler (`ops/`) to trigger nightly fine‑tunes, security scans, etc.
