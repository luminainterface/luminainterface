import os
import httpx
from fastapi import FastAPI, Request, HTTPException
import logging
import json

app = FastAPI()

MISTRAL_URL = os.getenv("MISTRAL_URL", "http://ollama:11436")
MISTRAL_MODEL = os.getenv("MISTRAL_MODEL", "mistral")

logger = logging.getLogger("masterchat-llm")
logging.basicConfig(level=logging.INFO)

@app.get("/health")
async def health():
    """Health check endpoint"""
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{MISTRAL_URL}/api/tags", timeout=5.0)
            resp.raise_for_status()
            return {"status": "healthy", "ollama_connected": True}
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return {"status": "unhealthy", "ollama_connected": False, "error": str(e)}

@app.post("/chat")
async def chat_llm(payload: dict):
    prompt = payload.get("prompt", "")
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{MISTRAL_URL}/api/generate",
                json={"prompt": prompt, "model": MISTRAL_MODEL},
                timeout=30.0
            )
            resp.raise_for_status()
            
            # Handle streaming response
            full_response = ""
            for line in resp.text.split('\n'):
                if not line.strip():
                    continue
                try:
                    chunk = json.loads(line)
                    if chunk.get("response"):
                        full_response += chunk["response"]
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse chunk: {e}")
                    continue
            
            logger.info(f"Full LLM response: {full_response}")
            return {
                "response": full_response,
                "confidence": 0.8  # Default confidence for now
            }
    except Exception as e:
        logger.error(f"Mistral call failed: {e}")
        raise HTTPException(status_code=500, detail=f"Mistral call failed: {str(e)}") 