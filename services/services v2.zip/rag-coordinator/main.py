from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import httpx
from qdrant_client import QdrantClient
from qdrant_client.http.models import Filter, SearchRequest
import numpy as np
import os
from sentence_transformers import SentenceTransformer
import redis.asyncio as aioredis
import json
import logging
from typing import List, Dict, Any, Optional
import time

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("rag-coordinator")

app = FastAPI(title="RAG Coordinator")

# Config
QDRANT_HOST = os.getenv("QDRANT_HOST", "qdrant")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", 6333))
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", 384))

# Initialize clients
qdrant = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT)
redis_client = aioredis.from_url(REDIS_URL)
model = SentenceTransformer(EMBEDDING_MODEL)

# Collections to search
COLLECTIONS = [
    "pdf_embeddings",
    "concepts",
    "chat_long",
    "graph_nodes"
]

class QueryRequest(BaseModel):
    query: str
    top_k: int = 5
    filters: Optional[Dict[str, Any]] = None

class SearchResult(BaseModel):
    id: str
    score: float
    payload: Dict[str, Any]
    collection: str

async def embed_query(query: str) -> List[float]:
    """Embed a query string."""
    return model.encode(query).tolist()

async def unified_retrieve(query: str, top_k: int = 5, filters: Optional[Dict] = None) -> List[SearchResult]:
    """Retrieve results from all collections."""
    query_vector = await embed_query(query)
    all_results = []
    
    for collection in COLLECTIONS:
        try:
            results = qdrant.search(
                collection_name=collection,
                query_vector=query_vector,
                limit=top_k,
                query_filter=Filter(**filters) if filters else None
            )
            
            # Add collection info to results
            for hit in results:
                all_results.append(SearchResult(
                    id=str(hit.id),
                    score=hit.score,
                    payload=hit.payload,
                    collection=collection
                ))
                
        except Exception as e:
            logger.error(f"Error searching collection {collection}: {str(e)}")
            continue
    
    # Sort by score and return top_k
    return sorted(all_results, key=lambda x: x.score, reverse=True)[:top_k]

@app.post("/query")
async def query_rag(request: QueryRequest):
    """Query RAG system with unified retrieval."""
    try:
        # 1. Retrieve contexts from all collections
        results = await unified_retrieve(
            request.query,
            top_k=request.top_k,
            filters=request.filters
        )
        
        # 2. Format contexts
        contexts = []
        sources = []
        for result in results:
            text = result.payload.get("text", result.payload.get("definition", ""))
            if text:
                contexts.append(text)
                sources.append({
                    "collection": result.collection,
                    "id": result.id,
                    "score": result.score
                })
        
        context_str = "\n".join(contexts)
        
        # 3. Call LLM with context
        async with httpx.AsyncClient() as client:
            llm_resp = await client.post(
                "http://masterchat-llm:8000/chat",
                json={"prompt": f"{context_str}\n\n{request.query}"}
            )
            llm_data = llm_resp.json()
        
        # 4. Notify concept trainer of new query
        await redis_client.publish(
            "lumina.rag_query",
            json.dumps({
                "query": request.query,
                "sources": sources,
                "timestamp": time.time()
            })
        )
        
        return {
            "answer": llm_data.get("response", ""),
            "sources": sources,
            "contexts": contexts
        }
        
    except Exception as e:
        logger.error(f"Error in RAG query: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    try:
        # Check Qdrant
        qdrant.get_collections()
        
        # Check Redis
        await redis_client.ping()
        
        return {"status": "healthy"}
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {"status": "unhealthy", "error": str(e)}

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint."""
    return {
        "collections": len(COLLECTIONS),
        "embedding_model": EMBEDDING_MODEL,
        "embedding_dim": EMBEDDING_DIM
    } 
    # 2. Retrieve top-k contexts from Qdrant
    search_result = qdrant.search(
        collection_name=QDRANT_COLLECTION,
        query_vector=query_vector,
        limit=request.top_k
    )
    contexts = [hit.payload.get("text", "") for hit in search_result]
    sources = [hit.payload.get("source", "unknown") for hit in search_result]
    context_str = "\n".join(contexts)

    # 3. Call LLM with context
    async with httpx.AsyncClient() as client:
        llm_resp = await client.post(
            "http://masterchat-llm:8000/chat",
            json={"prompt": f"{context_str}\n\n{request.query}"}
        )
        llm_data = llm_resp.json()

    return {
        "answer": llm_data.get("response", ""),
        "sources": sources,
        "contexts": contexts
    } 