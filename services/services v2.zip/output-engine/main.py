from fastapi import FastAPI, HTTPException, Response, BackgroundTasks
import httpx
import os
import numpy as np
from prometheus_fastapi_instrumentator import Instrumentator
from pydantic import BaseModel
from typing import Dict, List, Optional, AsyncGenerator, Any
import logging
from sentence_transformers import SentenceTransformer, CrossEncoder
from prometheus_client import Histogram, Counter
import backoff
import json
import asyncio
import redis
import pickle
import hashlib
from datetime import datetime, timedelta
from sklearn.decomposition import PCA
from sklearn.preprocessing import normalize
import spacy
from qdrant_client import QdrantClient
from qdrant_client.http import models
import time

DICT_URL = os.getenv("DICT_URL", "http://concept-dictionary:8000")
TRAINER_URL = os.getenv("TRAINER_URL", "http://concept-trainer-growable:8905")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://ollama:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "mistral")
TOP_K_CONCEPTS = int(os.getenv("TOP_K_CONCEPTS", "3"))
SIMILARITY_THRESHOLD = float(os.getenv("SIMILARITY_THRESHOLD", "0.3"))
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
EMBEDDING_CACHE_TTL = int(os.getenv("EMBEDDING_CACHE_TTL", "86400"))  # 24 hours
REVECTORIZATION_INTERVAL = int(os.getenv("REVECTORIZATION_INTERVAL", "604800"))  # 7 days
REDUCED_DIMENSIONS = int(os.getenv("REDUCED_DIMENSIONS", "128"))
FEEDBACK_WEIGHT = float(os.getenv("FEEDBACK_WEIGHT", "0.1"))

# Initialize models
embedding_model = SentenceTransformer(os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2"))
cross_encoder = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
pca = PCA(n_components=REDUCED_DIMENSIONS)
nlp = spacy.load("en_core_web_lg")

# Initialize Redis client
redis_client = redis.Redis.from_url(REDIS_URL, decode_responses=False)

# Initialize Qdrant client
qdrant_url = os.getenv("QDRANT_URL", "http://localhost:6333")
qdrant_client = QdrantClient(url=qdrant_url)

# Initialize metrics
INFERENCE_LATENCY = Histogram(
    'output_engine_inference_latency_seconds',
    'Time spent generating responses'
)
GENERATION_SUCCESS = Counter(
    'output_engine_generation_success_total',
    'Number of successful generations'
)
GENERATION_FAILURE = Counter(
    'output_engine_generation_failure_total',
    'Number of failed generations'
)
CONTEXT_RETRIEVAL_LATENCY = Histogram(
    'output_engine_context_retrieval_seconds',
    'Time spent retrieving context'
)
RERANKING_LATENCY = Histogram(
    'output_engine_reranking_seconds',
    'Time spent reranking results'
)
CACHE_HIT = Counter(
    'output_engine_cache_hit_total',
    'Number of cache hits for embeddings'
)
CACHE_MISS = Counter(
    'output_engine_cache_miss_total',
    'Number of cache misses for embeddings'
)
REVECTORIZATION_SUCCESS = Counter(
    'output_engine_revectorization_success_total',
    'Number of successful re-vectorizations'
)
REVECTORIZATION_FAILURE = Counter(
    'output_engine_revectorization_failure_total',
    'Number of failed re-vectorizations'
)
FEEDBACK_COUNT = Counter(
    'output_engine_feedback_total',
    'Number of feedback entries received'
)

app = FastAPI(title="Output Engine (NN)")
Instrumentator().instrument(app).expose(app)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("output-engine")

class ResponsePayload(BaseModel):
    prompt: str
    context: Optional[Dict] = None
    stream: Optional[bool] = False

class FeedbackPayload(BaseModel):
    query: str
    response: str
    rating: int  # 1-5 scale
    feedback: Optional[str] = None
    concepts_used: List[str]

class ChatRequest(BaseModel):
    text: str
    stream: Optional[bool] = False

# Few-shot examples for different types of queries
FEW_SHOT_EXAMPLES = {
    "definition": [
        {
            "query": "What is quantum computing?",
            "context": "Quantum computing is a type of computing that uses quantum bits (qubits) to process information.",
            "response": "Quantum computing is a revolutionary computing paradigm that leverages the principles of quantum mechanics. Unlike classical computers that use bits (0s and 1s), quantum computers use quantum bits or qubits, which can exist in multiple states simultaneously through superposition. This allows quantum computers to perform certain calculations exponentially faster than classical computers, particularly in areas like cryptography, optimization, and simulation of quantum systems."
        }
    ],
    "comparison": [
        {
            "query": "Compare quantum and classical computing",
            "context": "Quantum computing uses qubits while classical computing uses bits.",
            "response": "Quantum and classical computing differ fundamentally in their approach to information processing. Classical computers use bits that can be either 0 or 1, while quantum computers use qubits that can exist in multiple states simultaneously through superposition. This key difference allows quantum computers to perform certain calculations much faster than classical computers, though they are currently more limited in their practical applications and require specialized conditions to operate."
        }
    ],
    "application": [
        {
            "query": "How is quantum computing used in cryptography?",
            "context": "Quantum computing can break traditional encryption methods.",
            "response": "Quantum computing has significant implications for cryptography. It can potentially break many current encryption methods, particularly those based on factoring large numbers or solving discrete logarithms. This has led to the development of post-quantum cryptography, which aims to create encryption methods that are resistant to quantum attacks. Quantum computing also enables new cryptographic protocols like quantum key distribution, which offers theoretically unbreakable security based on the principles of quantum mechanics."
        }
    ]
}

def get_query_type(query: str) -> str:
    """Determine the type of query for few-shot example selection."""
    query = query.lower()
    if any(word in query for word in ["what is", "define", "definition"]):
        return "definition"
    elif any(word in query for word in ["compare", "difference", "versus", "vs"]):
        return "comparison"
    elif any(word in query for word in ["how", "use", "apply", "application"]):
        return "application"
    return "definition"  # default

def build_enhanced_prompt(query: str, contexts: List[Dict]) -> str:
    """Build an enhanced prompt with multiple contexts, few-shot examples, and clear instructions."""
    # Get relevant few-shot examples
    query_type = get_query_type(query)
    examples = FEW_SHOT_EXAMPLES.get(query_type, FEW_SHOT_EXAMPLES["definition"])
    
    # Build context section
    context_text = "\n\n".join([
        f"Context {i+1} (Relevance: {ctx['score']:.2f}):\n{ctx['text']}"
        for i, ctx in enumerate(contexts)
    ])
    
    # Build few-shot examples section
    examples_text = "\n\n".join([
        f"Example {i+1}:\nQuery: {ex['query']}\nContext: {ex['context']}\nResponse: {ex['response']}"
        for i, ex in enumerate(examples)
    ])
    
    return f"""### Context:
{context_text}

### Few-shot Examples:
{examples_text}

### Task:
Provide a comprehensive, clear, and insightful answer to the user's query. Use the provided contexts to inform your response, but feel free to synthesize and expand upon them. Follow the style and depth of the examples provided.

### Query:
{query}

### Answer:"""

def reduce_dimensions(embedding: np.ndarray) -> np.ndarray:
    """Reduce embedding dimensions using PCA."""
    return pca.transform(embedding.reshape(1, -1)).flatten()

def update_embedding_with_feedback(original_embedding: np.ndarray, feedback_embedding: np.ndarray, rating: int) -> np.ndarray:
    """Update embedding based on feedback."""
    # Normalize the feedback weight based on rating (1-5)
    weight = FEEDBACK_WEIGHT * (rating / 5.0)
    # Combine original and feedback embeddings
    return (1 - weight) * original_embedding + weight * feedback_embedding

async def store_feedback(feedback: FeedbackPayload):
    """Store feedback for continuous improvement."""
    try:
        # Generate embedding for the feedback
        feedback_embedding = embedding_model.encode(feedback.query)
        
        # Get original embedding
        original_embedding = await get_cached_embedding(feedback.query)
        if original_embedding is not None:
            # Update embedding based on feedback
            updated_embedding = update_embedding_with_feedback(
                original_embedding,
                feedback_embedding,
                feedback.rating
            )
            # Cache the updated embedding
            await cache_embedding(feedback.query, updated_embedding)
        
        # Store feedback in Redis for analysis
        feedback_key = f"feedback:{hashlib.md5(feedback.query.encode()).hexdigest()}"
        redis_client.setex(
            feedback_key,
            EMBEDDING_CACHE_TTL,
            pickle.dumps({
                "query": feedback.query,
                "response": feedback.response,
                "rating": feedback.rating,
                "feedback": feedback.feedback,
                "concepts_used": feedback.concepts_used,
                "timestamp": datetime.now().isoformat()
            })
        )
        
        FEEDBACK_COUNT.inc()
        logger.info(f"Stored feedback for query: {feedback.query}")
        
    except Exception as e:
        logger.error(f"Error storing feedback: {e}", exc_info=True)
        raise

@app.post("/feedback")
async def submit_feedback(feedback: FeedbackPayload):
    """Submit feedback for response improvement."""
    try:
        await store_feedback(feedback)
        return {"status": "success", "message": "Feedback stored successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def get_embedding_cache_key(text: str) -> str:
    """Generate a cache key for an embedding."""
    return f"embedding:{hashlib.md5(text.encode()).hexdigest()}"

async def get_cached_embedding(text: str) -> Optional[np.ndarray]:
    """Retrieve embedding from cache if available."""
    cache_key = get_embedding_cache_key(text)
    cached = redis_client.get(cache_key)
    if cached:
        CACHE_HIT.inc()
        return pickle.loads(cached)
    CACHE_MISS.inc()
    return None

async def cache_embedding(text: str, embedding: np.ndarray):
    """Cache an embedding with TTL."""
    cache_key = get_embedding_cache_key(text)
    # Reduce dimensions before caching
    reduced_embedding = reduce_dimensions(embedding)
    redis_client.setex(
        cache_key,
        EMBEDDING_CACHE_TTL,
        pickle.dumps(reduced_embedding)
    )

async def get_or_create_embedding(text: str) -> np.ndarray:
    """Get embedding from cache or create new one."""
    cached = await get_cached_embedding(text)
    if cached is not None:
        return cached
    
    embedding = embedding_model.encode(text)
    await cache_embedding(text, embedding)
    return embedding

async def revectorize_concepts():
    """Re-vectorize all concepts in the dictionary."""
    try:
        logger.info("Starting concept re-vectorization")
        async with httpx.AsyncClient() as client:
            # Get all concepts
            resp = await client.get(f"{DICT_URL}/concepts", timeout=30)
            resp.raise_for_status()
            concepts = resp.json()
            
            if not concepts:
                logger.info("No concepts found for re-vectorization")
                return
            
            # Collect all embeddings for PCA fitting
            all_embeddings = []
            for concept in concepts:
                embedding = embedding_model.encode(
                    f"{concept['term']} {concept.get('definition', '')}"
                )
                all_embeddings.append(embedding)
            
            if not all_embeddings:
                logger.info("No embeddings generated for concepts")
                return
                
            # Fit PCA on all embeddings
            all_embeddings = np.array(all_embeddings)
            if len(all_embeddings.shape) == 1:
                all_embeddings = all_embeddings.reshape(1, -1)
            pca.fit(all_embeddings)
            
            # Re-vectorize each concept
            for concept, embedding in zip(concepts, all_embeddings):
                # Reduce dimensions
                reduced_embedding = reduce_dimensions(embedding)
                
                # Update concept in dictionary
                await client.put(
                    f"{DICT_URL}/concepts/{concept['term']}",
                    json={
                        "term": concept["term"],
                        "definition": concept.get("definition", ""),
                        "embedding": reduced_embedding.tolist()
                    },
                    timeout=5
                )
                
                # Update cache
                await cache_embedding(
                    f"{concept['term']} {concept.get('definition', '')}",
                    embedding
                )
            
            REVECTORIZATION_SUCCESS.inc()
            logger.info("Concept re-vectorization completed successfully")
            
    except Exception as e:
        REVECTORIZATION_FAILURE.inc()
        logger.error(f"Re-vectorization failed: {e}", exc_info=True)
        raise

@app.on_event("startup")
async def startup_event():
    """Initialize background tasks on startup."""
    # Schedule periodic re-vectorization
    asyncio.create_task(schedule_revectorization())

async def schedule_revectorization():
    """Schedule periodic re-vectorization."""
    while True:
        try:
            await revectorize_concepts()
        except Exception as e:
            logger.error(f"Re-vectorization task failed: {e}")
        await asyncio.sleep(REVECTORIZATION_INTERVAL)

@backoff.on_exception(
    backoff.expo,
    (httpx.RequestError, httpx.HTTPError),
    max_tries=3
)
async def generate_with_llm(prompt: str, stream: bool = False) -> AsyncGenerator[str, None]:
    """Generate response using Ollama LLM with streaming support"""
    async with httpx.AsyncClient() as client:
        try:
            if stream:
                async with client.stream(
                    "POST",
                    f"{OLLAMA_URL}/api/generate",
                    json={
                        "model": OLLAMA_MODEL,
                        "prompt": prompt,
                        "stream": True
                    },
                    timeout=30.0
                ) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        if line.strip():
                            try:
                                chunk = json.loads(line)
                                if "response" in chunk:
                                    yield chunk["response"]
                            except json.JSONDecodeError:
                                continue
            else:
                response = await client.post(
                    f"{OLLAMA_URL}/api/generate",
                    json={
                        "model": OLLAMA_MODEL,
                        "prompt": prompt,
                        "stream": False
                    },
                    timeout=30.0
                )
                response.raise_for_status()
                yield response.json().get("response", "")
        except Exception as e:
            logger.error(f"LLM generation failed: {e}")
            raise

@app.get("/health")
async def health():
    """Health check endpoint"""
    try:
        # Check if we can reach the concept dictionary
        async with httpx.AsyncClient() as client:
            dict_resp = await client.get(f"{DICT_URL}/health", timeout=5)
            dict_resp.raise_for_status()
            
            # Check if we can reach the trainer
            trainer_resp = await client.get(f"{TRAINER_URL}/health", timeout=5)
            trainer_resp.raise_for_status()
            
            # Check if we can reach Ollama
            ollama_resp = await client.get(f"{OLLAMA_URL}/api/tags", timeout=5)
            ollama_resp.raise_for_status()
            
            # Check Redis connection
            redis_client.ping()
            
            # Check Qdrant connection
            qdrant_client.get_collections()
            
            return {
                "status": "healthy",
                "dependencies": {
                    "concept_dictionary": dict_resp.json(),
                    "trainer": trainer_resp.json(),
                    "ollama": ollama_resp.json(),
                    "redis": "connected",
                    "qdrant": "connected"
                }
            }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }

@app.post("/respond")
async def respond(payload: ResponsePayload):
    """Generate a response using the NN model with RAG and LLM"""
    try:
        logger.info(f"Received /respond request: {payload}")
        
        with INFERENCE_LATENCY.time():
            # 1) fetch relevant concepts
            with CONTEXT_RETRIEVAL_LATENCY.time():
                async with httpx.AsyncClient() as client:
                    try:
                        resp = await client.get(
                            f"{DICT_URL}/concepts",
                            timeout=5
                        )
                        resp.raise_for_status()
                        all_concepts = resp.json()
                        
                        # Filter concepts based on prompt
                        concepts = [c for c in all_concepts if payload.prompt.lower() in c["term"].lower() or payload.prompt.lower() in c["definition"].lower()][:TOP_K_CONCEPTS]
                        logger.info(f"Concepts found: {[c['term'] for c in concepts]}")
                    except Exception as e:
                        logger.error(f"Error fetching concepts: {e}")
                        raise

            # 2) generate embeddings and compute similarities
            prompt_embedding = await get_or_create_embedding(payload.prompt)
            concept_scores = []
            
            for c in concepts:
                # Check for valid embedding
                embedding = c.get("embedding")
                if not embedding or not isinstance(embedding, list) or len(embedding) != len(prompt_embedding):
                    logger.warning(f"Concept '{c.get('term')}' missing or invalid embedding.")
                    continue
                # Compute cosine similarity
                emb_a = np.array(prompt_embedding)
                emb_b = np.array(embedding)
                sim = float(np.dot(emb_a, emb_b) / (np.linalg.norm(emb_a) * np.linalg.norm(emb_b) + 1e-8))
                concept_scores.append({
                    "concept": c,
                    "score": sim,
                    "text": f"Concept: {c['term']}\nDefinition: {c.get('definition', '')}"
                })
            
            # 3) Re-rank using cross-encoder
            with RERANKING_LATENCY.time():
                if concept_scores:
                    # Prepare pairs for cross-encoder
                    pairs = [(payload.prompt, item["text"]) for item in concept_scores]
                    # Get cross-encoder scores
                    cross_scores = cross_encoder.predict(pairs)
                    # Update scores with cross-encoder results
                    for item, cross_score in zip(concept_scores, cross_scores):
                        item["score"] = (item["score"] + float(cross_score)) / 2
            
            # Sort by final scores
            concept_scores.sort(key=lambda x: x["score"], reverse=True)
            
            if not concept_scores or concept_scores[0]["score"] < SIMILARITY_THRESHOLD:
                logger.warning("No valid concept match found above threshold.")
                GENERATION_FAILURE.inc()
                return {
                    "response": "NN could not answer.",
                    "confidence": 0.0,
                    "concepts_used": []
                }
            
            # 4) Build enhanced prompt with multiple contexts
            prompt = build_enhanced_prompt(payload.prompt, concept_scores)
            
            if payload.stream:
                # Return streaming response
                return Response(
                    content=generate_with_llm(prompt, stream=True),
                    media_type="text/event-stream"
                )
            else:
                # Generate complete response
                async for response in generate_with_llm(prompt, stream=False):
                    GENERATION_SUCCESS.inc()
                    return {
                        "response": response,
                        "confidence": concept_scores[0]["score"],
                        "concepts_used": [cs["concept"]["term"] for cs in concept_scores]
                    }
            
    except Exception as e:
        logger.error(f"/respond failed: {e}", exc_info=True)
        GENERATION_FAILURE.inc()
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/chat")
async def chat(request: ChatRequest):
    """Chat endpoint that wraps the respond endpoint for compatibility"""
    try:
        # Convert chat request to response payload
        payload = ResponsePayload(
            prompt=request.text,
            stream=request.stream
        )
        
        # Use existing respond endpoint
        response = await respond(payload)
        
        # Return in chat format
        return {
            "response": response["response"],
            "confidence": response["confidence"],
            "concepts_used": response["concepts_used"]
        }
    except Exception as e:
        logger.error(f"/chat failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e)) 