from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import redis
from qdrant_client import QdrantClient
import json
from typing import Dict, Any, List
import os
import time

app = FastAPI()

# Initialize Redis connection
redis_client = redis.Redis(
    host=os.getenv("REDIS_HOST", "redis"),
    port=int(os.getenv("REDIS_PORT", 6379)),
    decode_responses=True
)

# Initialize Qdrant client
qdrant_client = QdrantClient(
    url=os.getenv("QDRANT_URL", "http://qdrant:6333")
)

class OutputRequest(BaseModel):
    model_id: str
    query: str
    parameters: Dict[str, Any] = {}

class OutputResponse(BaseModel):
    prediction_id: str
    results: List[Dict[str, Any]]
    metadata: Dict[str, Any]

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.post("/output")
async def generate_output(request: OutputRequest):
    try:
        # Generate a unique prediction ID
        prediction_id = f"{request.model_id}_{int(time.time())}"
        
        # Store the request in Redis
        key = f"output:{prediction_id}"
        redis_client.set(key, json.dumps(request.dict()))
        
        # TODO: Implement actual output generation logic here
        # This is a placeholder response
        response = OutputResponse(
            prediction_id=prediction_id,
            results=[{"text": "Sample output"}],
            metadata={"model_id": request.model_id}
        )
        
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/output/{prediction_id}")
async def get_output(prediction_id: str):
    try:
        key = f"output:{prediction_id}"
        output = redis_client.get(key)
        if output:
            return json.loads(output)
        raise HTTPException(status_code=404, detail="Output not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 