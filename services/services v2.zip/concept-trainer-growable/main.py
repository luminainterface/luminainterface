import os
import torch
import torch.nn as nn
import torch.optim as optim
from fastapi import FastAPI, HTTPException, APIRouter, BackgroundTasks
from pydantic import BaseModel
from typing import List, Dict, Optional
import numpy as np
from datetime import datetime
import redis
import json
import logging
import traceback
from model import GrowableConceptNet
import asyncio
from prometheus_client import Counter, Gauge, Histogram, make_asgi_app
from prometheus_fastapi_instrumentator import Instrumentator
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import httpx
import torch.nn.functional as F
from growth_feedback import GrowthFeedbackManager
from contextlib import asynccontextmanager
import time
from sentence_transformers import SentenceTransformer
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from qdrant_client import QdrantClient

# Environment variables
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
DICT_URL = os.getenv("DICT_URL", "http://concept-dictionary:8000")
QDRANT_URL = os.getenv("QDRANT_URL", "http://qdrant:6333")
BATCH_SIZE = int(os.getenv("BATCH_SIZE", "32"))
TRAIN_INTERVAL = int(os.getenv("TRAIN_INTERVAL", "3600"))  # 1 hour
DEVICE = os.getenv("DEVICE", "cuda" if torch.cuda.is_available() else "cpu")

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,  # Set to DEBUG for more verbose logging
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Growable Concept Net API",
    debug=True  # Enable debug mode
)

# Create routers
monitoring_router = APIRouter()
model_router = APIRouter()

# Add routes to routers
@monitoring_router.get("/monitoring/growth")
async def get_growth_history():
    """Get the history of model growth events"""
    try:
        return growth_events
    except Exception as e:
        logger.error(f"Error getting growth history: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

@monitoring_router.get("/monitoring/service-inputs")
async def get_service_inputs():
    """Get statistics about inputs from different services"""
    try:
        return service_stats
    except Exception as e:
        logger.error(f"Error getting service inputs: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

@monitoring_router.get("/monitoring/drift/{concept_id}")
async def get_concept_drift(concept_id: str):
    """Get drift history and metrics for a specific concept"""
    try:
        if model is None:
            raise HTTPException(status_code=503, detail="Model not initialized")
            
        metrics = model.get_concept_metrics(concept_id)
        if not metrics:
            return {
                "concept_id": concept_id,
                "status": "not_found",
                "message": f"No metrics found for concept {concept_id}"
            }
            
        return {
            "concept_id": concept_id,
            "status": "success",
            "metrics": {
                "last_drift": metrics["last_drift"],
                "drift_trend": metrics["drift_trend"],
                "maturity_score": metrics["maturity_score"],
                "growth_threshold": metrics["growth_threshold"],
                "last_update": metrics["last_update"],
                "drift_history": metrics["drift_history"][-10:]  # Last 10 drift measurements
            }
        }
    except Exception as e:
        logger.error(f"Error getting concept drift: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

@monitoring_router.get("/monitoring/network/stats")
async def get_network_stats():
    """Get overall network statistics"""
    try:
        if model is None:
            raise HTTPException(status_code=503, detail="Model not initialized")
        
        stats = model.get_network_stats()
        
        # Add maturity statistics
        maturity_scores = [
            metrics["maturity_score"]
            for metrics in model.concept_metrics.values()
        ]
        
        stats.update({
            "maturity_stats": {
                "mean": sum(maturity_scores) / len(maturity_scores) if maturity_scores else 0.0,
                "min": min(maturity_scores) if maturity_scores else 0.0,
                "max": max(maturity_scores) if maturity_scores else 0.0,
                "mature_concepts": sum(1 for score in maturity_scores if score > 0.7)
            }
        })
        
        return stats
    except Exception as e:
        logger.error(f"Error getting network stats: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

# Include routers
app.include_router(monitoring_router, tags=["monitoring"])
app.include_router(model_router, tags=["model"])

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add Prometheus metrics endpoint
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

# Initialize Prometheus instrumentator
instrumentator = Instrumentator().instrument(app)
instrumentator.expose(app, include_in_schema=True, should_gzip=True)

# Prometheus metrics
MODEL_GROWTH_COUNTER = Counter('model_growth_events_total', 'Total number of model growth events')
LAYER_SIZE_GAUGE = Gauge('layer_size', 'Current size of each layer', ['layer_index'])
DRIFT_HISTOGRAM = Histogram('concept_drift', 'Distribution of concept drift values')
DRIFT_TREND_GAUGE = Gauge('concept_drift_trend', 'Trend of concept drift over time', ['concept_id'])
MATURITY_SCORE_GAUGE = Gauge('concept_maturity', 'Maturity score for each concept', ['concept_id'])
GROWTH_THRESHOLD_GAUGE = Gauge('concept_growth_threshold', 'Current growth threshold for each concept', ['concept_id'])
SERVICE_INPUT_COUNTER = Counter('service_inputs_total', 'Inputs received from each service', ['service_name'])

# Initialize in-memory storage for development
growth_events = []
drift_history = {}
service_stats = {
    'dual_chat': 0,
    'crawler': 0,
    'masterchat': 0
}

# Error handling middleware
class ErrorLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        try:
            response = await call_next(request)
            return response
        except Exception as e:
            logger.error(f"Error processing request: {str(e)}")
            logger.error(traceback.format_exc())
            return JSONResponse(
                status_code=500,
                content={"detail": str(e)}
            )

app.add_middleware(ErrorLoggingMiddleware)

# Model state
model = None
optimizer = None
criterion = nn.CrossEntropyLoss()

# Data models
class TrainingData(BaseModel):
    concept_id: str
    inputs: List[List[float]]
    targets: List[int]  # Binary targets (0 or 1)
    target_onehot: Optional[List[List[float]]] = None  # Optional one-hot encoded targets
    metadata: Optional[Dict] = None

class GrowthRequest(BaseModel):
    concept_id: str
    layer_idx: int
    new_size: int

class TrainingRequest(BaseModel):
    concept_id: str
    text: str
    label: Optional[int] = None
    metadata: Optional[Dict] = None

class TrainingResponse(BaseModel):
    concept_id: str
    confidence: float
    version: int
    metadata: Optional[Dict] = None

# Helper functions
def record_growth_event(layer_idx: int, old_size: int, new_size: int):
    """Record a growth event in memory and Prometheus"""
    event = {
        'timestamp': datetime.now().isoformat(),
        'layer_idx': layer_idx,
        'old_size': old_size,
        'new_size': new_size,
        'growth_factor': round(new_size / old_size, 2)
    }
    
    # Record in memory
    growth_events.append(event)
    if len(growth_events) > 1000:
        growth_events.pop(0)
    
    # Update Prometheus metrics
    MODEL_GROWTH_COUNTER.inc()
    LAYER_SIZE_GAUGE.labels(layer_index=layer_idx).set(new_size)
    
    # Log growth event prominently
    logger.info("\n=== GROWTH EVENT DETECTED ===")
    logger.info(f"Layer {layer_idx}: {old_size} -> {new_size} neurons")
    logger.info(f"Growth factor: {event['growth_factor']}x")
    logger.info(f"Total growth events: {len(growth_events)}")
    logger.info("=============================\n")

def record_drift(concept_id: str, drift: float):
    """Record concept drift in memory and Prometheus"""
    DRIFT_HISTOGRAM.observe(drift)
    if concept_id not in drift_history:
        drift_history[concept_id] = {}
    drift_history[concept_id][datetime.now().isoformat()] = drift
    
    # Update drift trend and maturity metrics
    if model and concept_id in model.concept_metrics:
        metrics = model.concept_metrics[concept_id]
        DRIFT_TREND_GAUGE.labels(concept_id=concept_id).set(metrics['drift_trend'])
        MATURITY_SCORE_GAUGE.labels(concept_id=concept_id).set(metrics['maturity_score'])
        GROWTH_THRESHOLD_GAUGE.labels(concept_id=concept_id).set(metrics['growth_threshold'])

# Model routes
@model_router.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Check Redis connection first
        try:
            await redis_client.ping()
            redis_healthy = True
        except Exception as e:
            logger.error(f"Redis health check failed: {e}")
            redis_healthy = False

        # Only perform model check if Redis is healthy
        if redis_healthy:
            try:
                # Use a smaller dummy input for health check
                dummy_input = torch.randn(1, 768, device=device)
                with torch.no_grad():
                    output = model(dummy_input)
                model_healthy = True
            except Exception as e:
                logger.error(f"Model health check failed: {e}")
                model_healthy = False
        else:
            model_healthy = False

        return {
            "status": "healthy" if (redis_healthy and model_healthy) else "unhealthy",
            "components": {
                "redis": "healthy" if redis_healthy else "unhealthy",
                "model": "healthy" if model_healthy else "unhealthy"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        logger.error(traceback.format_exc())
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@model_router.post("/evaluate")
async def evaluate_concept(data: TrainingData):
    """Evaluate a concept without training"""
    try:
        logger.info(f"Evaluating concept {data.concept_id}")
        logger.info(f"Input shape: {len(data.inputs)}x{len(data.inputs[0])}")
        logger.info(f"Number of targets: {len(data.targets)}")
        logger.info(f"Raw targets: {data.targets}")
        
        # Validate input dimensions
        if len(data.inputs[0]) != 768:
            error_msg = f"Expected input dimension 768, got {len(data.inputs[0])}"
            logger.error(error_msg)
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Convert data to tensors
        try:
            # Handle inputs
            inputs = torch.tensor(data.inputs, dtype=torch.float32)
            if len(inputs.shape) < 2:
                inputs = inputs.view(-1, model.input_size)
            
            # Handle binary targets
            targets = torch.tensor(data.targets, dtype=torch.long)
            if len(targets.shape) < 1:
                targets = targets.view(-1)
            
            logger.info(f"Successfully created tensors")
            logger.info(f"Input tensor shape: {inputs.shape}")
            logger.info(f"Target tensor shape: {targets.shape}")
            logger.info(f"Target values: {targets}")
        except Exception as e:
            error_msg = f"Error creating tensors: {str(e)}"
            logger.error(error_msg)
            logger.error(traceback.format_exc())
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Forward pass in eval mode
        try:
            model.eval()  # Set to evaluation mode
            with torch.no_grad():
                outputs = model(inputs)  # This will return log probabilities for both classes
                logger.info(f"Model output shape: {outputs.shape}")
                logger.info(f"Model output values: {outputs}")
                
                # Convert outputs to probabilities
                probs = torch.exp(outputs)
                logger.info(f"Probabilities shape: {probs.shape}")
                logger.info(f"Probabilities: {probs}")
                
                # Get binary predictions
                predictions = torch.argmax(probs, dim=1)  # Use last dimension for class prediction
                logger.info(f"Predictions shape: {predictions.shape}")
                logger.info(f"Predictions: {predictions}")
                
                # Calculate metrics
                accuracy = (predictions == targets).float().mean()
                loss = F.nll_loss(outputs, targets)  # Use NLL loss directly
            model.train()  # Reset to training mode
            logger.info(f"Evaluation successful")
            logger.info(f"Loss: {loss.item()}, Accuracy: {accuracy.item()}")
        except Exception as e:
            error_msg = f"Error in evaluation: {str(e)}"
            logger.error(error_msg)
            logger.error(traceback.format_exc())
            raise HTTPException(status_code=500, detail=error_msg)
            
        # Evaluate drift without updating model
        try:
            drift = model.evaluate_drift(data.concept_id, inputs, inputs)
            logger.info(f"Drift evaluation successful")
            logger.info(f"Concept drift: {drift}")
            
            # Record drift in monitoring
            record_drift(data.concept_id, drift)
        except Exception as e:
            error_msg = f"Error evaluating drift: {str(e)}"
            logger.error(error_msg)
            logger.error(traceback.format_exc())
            raise HTTPException(status_code=500, detail=error_msg)
        
        return {
            "status": "success",
            "loss": loss.item(),
            "accuracy": accuracy.item(),
            "drift": drift,
            "predictions": predictions.tolist(),
            "probabilities": probs.tolist()  # Return actual probabilities
        }
        
    except HTTPException:
        raise
    except Exception as e:
        error_msg = f"Unexpected error during evaluation: {str(e)}"
        logger.error(error_msg)
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=error_msg)

# Initialize Redis client with timeouts and retry logic
redis_client = redis.from_url(
    REDIS_URL,
    encoding="utf-8",
    decode_responses=True,
    socket_timeout=5.0,  # 5 second timeout for operations
    socket_connect_timeout=5.0,  # 5 second timeout for connections
    retry_on_timeout=True,
    health_check_interval=30  # Check connection health every 30 seconds
)

# Add Redis connection error handler
@asynccontextmanager
async def get_redis_connection():
    """Context manager for Redis operations with retry logic"""
    max_retries = 3
    retry_delay = 1.0  # seconds
    
    for attempt in range(max_retries):
        try:
            yield redis_client
            break
        except redis.ConnectionError as e:
            if attempt == max_retries - 1:
                logger.error(f"Redis connection failed after {max_retries} attempts: {e}")
                raise
            logger.warning(f"Redis connection attempt {attempt + 1} failed: {e}")
            await asyncio.sleep(retry_delay)
        except Exception as e:
            logger.error(f"Unexpected Redis error: {e}")
            raise

# Graph API client
GRAPH_API_URL = os.getenv("GRAPH_API_URL", "http://graph-api:8000")

# Initialize feedback manager
feedback_manager = None

# Initialize Qdrant client
qdrant_client = QdrantClient(url=QDRANT_URL)

# Initialize embedding model
model = SentenceTransformer('all-MiniLM-L6-v2').to(DEVICE)

# Initialize metrics
TRAINING_BATCHES = Counter(
    'concept_trainer_batches_total',
    'Number of training batches processed'
)

TRAINING_SAMPLES = Counter(
    'concept_trainer_samples_total',
    'Number of training samples processed'
)

TRAINING_LATENCY = Histogram(
    'concept_trainer_latency_seconds',
    'Time spent on training operations'
)

MODEL_VERSION = Gauge(
    'concept_trainer_model_version',
    'Current model version'
)

@app.on_event("startup")
async def startup_event():
    """Initialize the model and start monitoring"""
    try:
        logger.info("Starting up application...")
        global model, optimizer, feedback_manager
        
        # Initialize model
        input_size = 768  # Default input size
        hidden_sizes = [384, 192, 128]  # Default hidden layer sizes
        logger.info(f"Creating new model with input_size={input_size}, hidden_sizes={hidden_sizes}")
        
        model = GrowableConceptNet(input_size, hidden_sizes)
        optimizer = optim.Adam(model.parameters())
        
        # Initialize feedback manager
        feedback_manager = GrowthFeedbackManager(
            graph_api_url=GRAPH_API_URL,
            redis_host=os.getenv("REDIS_HOST", "redis"),
            redis_port=int(os.getenv("REDIS_PORT", 6379))
        )
        
        # Initialize Prometheus metrics
        for i, size in enumerate(hidden_sizes):
            LAYER_SIZE_GAUGE.labels(layer_index=i).set(size)
        
        # Initialize Qdrant client
        qdrant_client = QdrantClient(url=QDRANT_URL)
        
        # Initialize embedding model
        model = SentenceTransformer('all-MiniLM-L6-v2').to(DEVICE)
        
        logger.info("Application startup complete")
    except Exception as e:
        logger.error(f"Error during startup: {e}")
        logger.error(traceback.format_exc())
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Clean up resources on shutdown"""
    if feedback_manager:
        await feedback_manager.close()

async def broadcast_growth_event(concept_id: str, layer_idx: int, old_size: int, new_size: int, reason: str):
    """Broadcast growth event to Redis and get feedback"""
    try:
        event = {
            "concept": concept_id,
            "layers": [layer.current_capacity for layer in model.layers],
            "reason": reason,
            "growth_factor": round(new_size / old_size, 2),
            "timestamp": datetime.now().isoformat(),
            "maturity": model.concept_metrics[concept_id]["maturity_score"] if concept_id in model.concept_metrics else 0.0
        }
        
        # Publish to Redis
        await redis_client.publish("lumina.growth", json.dumps(event))
        logger.info(f"Broadcast growth event: {event}")
        
        # Get growth feedback
        if feedback_manager:
            feedback = await feedback_manager.analyze_growth_context(concept_id, event)
            logger.info(f"Growth feedback received: {feedback}")
            
            # If there are context gaps, trigger crawler
            if feedback.get("context_gaps"):
                crawl_request = {
                    "type": "crawl_request",
                    "concept": concept_id,
                    "priority": "high",
                    "gaps": feedback["context_gaps"]
                }
                await redis_client.publish("lumina.crawl", json.dumps(crawl_request))
                logger.info(f"Triggered crawler for concept {concept_id}")
        
        # Update Graph API
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{GRAPH_API_URL}/concept/update",
                json={
                    "term": concept_id,
                    "embedding": model.get_concept_embedding(concept_id).tolist(),
                    "maturity": event["maturity"],
                    "growth_event": True,
                    "growth_metadata": {
                        "previous_layers": [layer.current_capacity for layer in model.layers],
                        "new_layers": [layer.current_capacity for layer in model.layers],
                        "trigger": reason,
                        "growth_factor": event["growth_factor"]
                    }
                }
            )
            if response.status_code != 200:
                logger.error(f"Failed to update Graph API: {response.text}")
            else:
                logger.info("Successfully updated Graph API")
                
    except Exception as e:
        logger.error(f"Error broadcasting growth event: {e}")
        logger.error(traceback.format_exc())

@model_router.post("/grow")
async def grow_layer(request: GrowthRequest):
    """Grow a layer to a new size"""
    try:
        logger.info(f"Growing layer {request.layer_idx} to size {request.new_size}")
        old_size = model.layers[request.layer_idx].current_capacity
        
        # Get growth reason
        metrics = model.get_concept_metrics(request.concept_id)
        reason = "drift_high" if metrics and metrics["last_drift"] > metrics["growth_threshold"] else "manual"
        
        # Grow the layer
        model.grow_layer(request.layer_idx, request.new_size)
        
        # Record growth event
        record_growth_event(request.layer_idx, old_size, request.new_size)
        
        # Broadcast growth event
        await broadcast_growth_event(
            request.concept_id,
            request.layer_idx,
            old_size,
            request.new_size,
            reason
        )
        
        # Save updated model state
        logger.info("Saving updated model state after growth...")
        torch.save({
            'model': model,
            'optimizer': optimizer.state_dict()
        }, '/app/data/model_state.pt')
        logger.info("Model state saved successfully")
        
        return {
            "status": "success",
            "message": f"Layer {request.layer_idx} grown from {old_size} to {request.new_size}",
            "growth_event": {
                "concept": request.concept_id,
                "reason": reason,
                "growth_factor": round(request.new_size / old_size, 2)
            }
        }
        
    except Exception as e:
        logger.error(f"Error during layer growth: {str(e)}")
        logger.exception("Full traceback:")
        raise HTTPException(status_code=500, detail=str(e))

# Monitoring routes
@app.get("/monitoring/growth", tags=["monitoring"])
async def get_growth_history():
    """Get the history of model growth events"""
    try:
        # Add summary statistics
        if not growth_events:
            return {
                "status": "no_growth",
                "message": "No growth events recorded yet",
                "events": []
            }
            
        latest = growth_events[-1]
        total_growth = sum(event['new_size'] - event['old_size'] for event in growth_events)
        
        return {
            "status": "growing" if len(growth_events) > 0 else "stable",
            "total_events": len(growth_events),
            "total_growth": total_growth,
            "latest_event": latest,
            "events": growth_events
        }
    except Exception as e:
        logger.error(f"Error getting growth history: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/monitoring/service-inputs", tags=["monitoring"])
async def get_service_inputs():
    """Get statistics about inputs from different services"""
    try:
        return service_stats
    except Exception as e:
        logger.error(f"Error getting service inputs: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/monitoring/drift/{concept_id}", tags=["monitoring"])
async def get_concept_drift(concept_id: str):
    """Get drift history for a specific concept"""
    try:
        return drift_history.get(concept_id, {})
    except Exception as e:
        logger.error(f"Error getting concept drift: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/monitoring/network/stats", tags=["monitoring"])
async def get_network_stats():
    """Get overall network statistics"""
    try:
        if model is None:
            raise HTTPException(status_code=503, detail="Model not initialized")
        
        current_sizes = [layer.current_capacity for layer in model.layers]
        initial_sizes = [384, 192, 128]  # Initial architecture
        growth_ratios = [round(curr/init, 2) for curr, init in zip(current_sizes, initial_sizes)]
        
        stats = {
            'num_layers': len(model.layers),
            'layer_sizes': current_sizes,
            'growth_ratios': growth_ratios,
            'total_params': sum(p.numel() for p in model.parameters()),
            'growth_events': len(growth_events),
            'concepts_tracked': len(drift_history),
            'last_growth': growth_events[-1] if growth_events else None,
            'total_growth_factor': round(sum(current_sizes) / sum(initial_sizes), 2)
        }
        
        # Log current network state
        logger.info("\n=== NETWORK STATUS UPDATE ===")
        logger.info(f"Layer sizes: {stats['layer_sizes']}")
        logger.info(f"Growth ratios: {stats['growth_ratios']}")
        logger.info(f"Total parameters: {stats['total_params']}")
        logger.info(f"Growth events: {stats['growth_events']}")
        logger.info(f"Total growth factor: {stats['total_growth_factor']}x")
        logger.info("===========================\n")
        
        return stats
    except Exception as e:
        logger.error(f"Error getting network stats: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

# Root health check
@app.get("/health")
async def root_health_check():
    """Root health check endpoint"""
    return {"status": "healthy"}

@app.middleware("http")
async def log_requests(request, call_next):
    """Log all incoming requests"""
    logger.debug(f"Request: {request.method} {request.url}")
    try:
        response = await call_next(request)
        logger.debug(f"Response: {response.status_code}")
        return response
    except Exception as e:
        logger.error(f"Request failed: {e}")
        raise

# Root endpoint for testing
@app.get("/")
async def root():
    """Root endpoint for testing"""
    logger.info("Root endpoint called")
    return {"status": "running", "endpoints": [
        "/health",
        "/monitoring/growth",
        "/monitoring/service-inputs",
        "/monitoring/drift/{concept_id}",
        "/monitoring/network/stats"
    ]}

@app.post("/train")
async def train_concept(request: TrainingRequest, background_tasks: BackgroundTasks):
    """Train a concept based on feedback."""
    try:
        # Validate input dimensions
        if len(request.text) != 768:
            raise HTTPException(
                status_code=422,
                detail=f"Invalid text length. Expected 768, got {len(request.text)}"
            )

        # Verify Redis connection using the context manager
        try:
            async with get_redis_connection() as redis:
                await redis.ping()
        except Exception as e:
            logger.error(f"Redis connection error: {str(e)}")
            raise HTTPException(
                status_code=503,
                detail="Service temporarily unavailable - Redis connection error"
            )

        # Process training request
        training_data = {
            "text": request.text,
            "embedding": embedding_model.encode(request.text).tolist(),
            "label": request.label,
            "metadata": request.metadata,
            "timestamp": time.time()
        }
        
        # Store training data
        key = f"training:{request.concept_id}"
        redis_client.setex(key, 86400, json.dumps(training_data))  # 24 hour TTL
        
        # Increment model version
        version_key = f"version:{request.concept_id}"
        version = redis_client.incr(version_key)
        
        # Calculate confidence (simplified)
        confidence = 0.8  # Placeholder for actual confidence calculation
        
        return TrainingResponse(
            concept_id=request.concept_id,
            confidence=confidence,
            version=version,
            metadata=request.metadata
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error in train_concept: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )

@app.get("/evaluate/{concept_id}")
async def evaluate_concept(concept_id: str, text: str):
    with training_latency.time():
        training_operations.inc()
        try:
            # Get training data
            key = f"training:{concept_id}"
            training_data = redis_client.get(key)
            if not training_data:
                raise HTTPException(status_code=404, detail="Concept not found")
            
            training_data = json.loads(training_data)
            
            # Generate query embedding
            query_embedding = embedding_model.encode(text)
            
            # Calculate similarity
            similarity = np.dot(query_embedding, training_data["embedding"]) / (
                np.linalg.norm(query_embedding) * np.linalg.norm(training_data["embedding"])
            )
            
            return {
                "concept_id": concept_id,
                "similarity": float(similarity),
                "confidence": float(similarity),
                "version": int(redis_client.get(f"version:{concept_id}") or 0)
            }
        except Exception as e:
            logger.error(f"Error evaluating concept: {str(e)}")
            raise HTTPException(status_code=500, detail="Internal server error")

async def train_on_concepts(concept_ids: List[str], batch_size: int):
    """Train on a batch of concepts"""
    try:
        with TRAINING_LATENCY.time():
            # Fetch concepts
            async with httpx.AsyncClient() as client:
                concepts = []
                for cid in concept_ids:
                    resp = await client.get(f"{DICT_URL}/concepts/{cid}")
                    if resp.status_code == 200:
                        concepts.append(resp.json())
            
            if not concepts:
                logger.warning("No concepts found for training")
                return
            
            # Prepare training data
            texts = [
                f"{c['term']} {c.get('definition', '')}"
                for c in concepts
            ]
            
            # Generate embeddings in batches
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                embeddings = model.encode(
                    batch,
                    batch_size=batch_size,
                    show_progress_bar=False
                )
                
                # Update concepts with new embeddings
                for j, embedding in enumerate(embeddings):
                    concept = concepts[i + j]
                    async with httpx.AsyncClient() as client:
                        await client.put(
                            f"{DICT_URL}/concepts/{concept['term']}",
                            json={
                                "term": concept["term"],
                                "definition": concept.get("definition", ""),
                                "embedding": embedding.tolist(),
                                "metadata": concept.get("metadata", {}),
                                "last_updated": datetime.utcnow().isoformat()
                            }
                        )
                
                TRAINING_BATCHES.inc()
                TRAINING_SAMPLES.inc(len(batch))
            
            # Increment model version
            MODEL_VERSION.inc()
            
            logger.info(f"Trained on {len(concepts)} concepts")
    except Exception as e:
        logger.error(f"Error during training: {e}")
        raise

@app.post("/train")
async def train(request: TrainingRequest, background_tasks: BackgroundTasks):
    """Train on specified concepts"""
    try:
        background_tasks.add_task(
            train_on_concepts,
            request.concept_ids,
            request.batch_size or BATCH_SIZE
        )
        return {
            "status": "success",
            "message": f"Training started on {len(request.concept_ids)} concepts"
        }
    except Exception as e:
        logger.error(f"Error scheduling training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

async def periodic_training():
    """Periodic training loop"""
    while True:
        try:
            # Get all concepts
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{DICT_URL}/concepts")
                if resp.status_code == 200:
                    concepts = resp.json()
                    if concepts:
                        # Train on all concepts
                        await train_on_concepts(
                            [c["term"] for c in concepts],
                            BATCH_SIZE
                        )
        except Exception as e:
            logger.error(f"Error in periodic training: {e}")
        
        await asyncio.sleep(TRAIN_INTERVAL)

@app.on_event("startup")
async def startup_event():
    """Start background tasks"""
    asyncio.create_task(periodic_training())

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8905, log_level="info") 