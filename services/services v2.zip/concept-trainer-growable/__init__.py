"""
Concept Trainer Growable package.
"""

# This file makes the directory a Python package 