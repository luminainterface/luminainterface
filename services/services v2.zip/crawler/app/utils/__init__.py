"""
Utility functions for the Wikipedia Graph Crawler
""" 