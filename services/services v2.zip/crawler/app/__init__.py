"""
Wikipedia Graph Crawler Service
"""

__version__ = "0.1.0" 