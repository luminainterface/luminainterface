from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
import logging
import os
import asyncio
from datetime import datetime, timedelta
import json
import uuid

from .api.router import router, crawler
from .core.crawler import Crawler
from .core.graph_processor import GraphProcessor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Wikipedia Graph Crawler",
    description="A service for crawling Wikipedia pages and building a knowledge graph",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API router
app.include_router(router, prefix="/api/v1")

# Global variables for background tasks
background_tasks = set()
PROCESS_INTERVAL = int(os.getenv("PROCESS_INTERVAL", "3600"))  # Default: 1 hour
INQUIRY_CHECK_INTERVAL = int(os.getenv("INQUIRY_CHECK_INTERVAL", "300"))  # Default: 5 minutes

async def process_inquiries():
    """Background task to process all inquiries with weight-based prioritization"""
    while True:
        try:
            logger.info("Processing inquiries")
            # Get next crawl request based on weight priority
            request = await crawler.redis_client.get_next_crawl_request()
            
            if request:
                concept = request.get('concept')
                inquiry_id = request.get('inquiry_id')
                source = request.get('source', 'system')
                
                try:
                    # Process the crawl request
                    result = await crawler.crawl(concept)
                    
                    if result:
                        # Store the vector and metadata
                        await crawler.redis_client.store_vector(
                            concept=concept,
                            vector=result.get('vector', []),
                            metadata={
                                'source': source,
                                'inquiry_id': inquiry_id,
                                'weight': request.get('weight', 0.5),
                                'crawl_timestamp': datetime.now().isoformat()
                            }
                        )
                        
                        # Update inquiry status
                        if inquiry_id:
                            await crawler.redis_client.update_inquiry_status(inquiry_id, "completed")
                            
                        logger.info(f"Successfully processed inquiry for concept: {concept}")
                    else:
                        # Handle failed crawl
                        if inquiry_id:
                            await crawler.redis_client.update_inquiry_status(inquiry_id, "failed")
                        await crawler.redis_client.add_to_dead_letter_queue(concept, "Crawl failed")
                        
                except Exception as e:
                    logger.error(f"Error processing inquiry for concept {concept}: {e}")
                    if inquiry_id:
                        await crawler.redis_client.update_inquiry_status(inquiry_id, "error")
                    await crawler.redis_client.add_to_dead_letter_queue(concept, str(e))
            else:
                logger.info("No inquiries found, falling back to graph crawling.")
                # If no inquiries, check graph for concepts to crawl
                await process_graph_concepts()
                
        except Exception as e:
            logger.error(f"Error in inquiry processing: {e}")

        await asyncio.sleep(INQUIRY_CHECK_INTERVAL)

async def process_graph_concepts():
    """Process concepts from the graph when no inquiries are pending"""
    try:
        graph_path = os.getenv("TRAINING_DATA_PATH")
        if not graph_path:
            logger.warning("No TRAINING_DATA_PATH set, cannot load graph.")
            return

        processor = GraphProcessor(crawler)
        if processor.load_graph(graph_path):
            concepts = processor.get_unprocessed_concepts()
            logger.info(f"Graph loaded. {len(concepts)} unprocessed concepts found.")
            for concept in concepts:
                logger.info(f"Adding graph concept to crawl queue: {concept}")
                await crawler.redis_client.add_to_crawl_queue(
                    concept=concept,
                    weight=0.3,  # Lower weight for graph-based concepts
                    source="graph"
                )
        else:
            logger.warning("Graph could not be loaded or was empty.")
    except Exception as e:
        logger.error(f"Error processing graph concepts: {e}")

async def start_background_tasks():
    """Start background tasks"""
    # Start inquiry processing task
    inquiry_task = asyncio.create_task(process_inquiries())
    background_tasks.add(inquiry_task)
    inquiry_task.add_done_callback(background_tasks.discard)

@app.on_event("startup")
async def startup_event():
    """Initialize the crawler on startup"""
    try:
        # Get configuration from environment variables
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
        qdrant_url = os.getenv("QDRANT_URL", "http://localhost:6333")
        graph_api_url = os.getenv("GRAPH_API_URL", "http://localhost:8200")
        concept_dict_url = os.getenv("CONCEPT_DICT_URL", "http://localhost:8000")
        embedding_model = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
        max_depth = int(os.getenv("WIKI_SEARCH_DEPTH", "2"))
        max_links = int(os.getenv("WIKI_MAX_RESULTS", "10"))
        
        # Initialize the crawler
        global crawler
        crawler = Crawler(
            redis_url=redis_url,
            qdrant_url=qdrant_url,
            graph_api_url=graph_api_url,
            concept_dict_url=concept_dict_url,
            embedding_model=embedding_model,
            max_depth=max_depth,
            max_links_per_page=max_links
        )
        
        logger.info("Crawler service initialized successfully")

        # Start background tasks
        await start_background_tasks()
        
    except Exception as e:
        logger.error(f"Error initializing crawler service: {str(e)}")
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    logger.info("Shutting down crawler service")
    # Cancel all background tasks
    for task in background_tasks:
        task.cancel()
    # Wait for all tasks to complete
    await asyncio.gather(*background_tasks, return_exceptions=True)

@app.get("/health")
async def health():
    return {"status": "ok"} 