from typing import Any, Optional, List, Dict
import json
import redis.asyncio as redis
import logging
from datetime import timedelta
import os
from .vector_store import VectorStore
import time

logger = logging.getLogger(__name__)

class RedisClient:
    def __init__(self, url: str, encoding: str = 'utf-8'):
        self.redis = redis.from_url(url, encoding=encoding)
        self.encoding = encoding
        self.system_crawl_channel = "lumina.system.crawl"
        self.crawl_queue = "crawler.queue"
        self.dead_letter_queue = "crawler.deadletter"
        self.vector_store = "crawler.vectors"
        self.inquiry_tracking = "crawler.inquiries"
        # Qdrant integration
        qdrant_url = os.getenv("QDRANT_URL", "http://qdrant:6333")
        self.qdrant = VectorStore(qdrant_url)
        
    async def __aenter__(self):
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.redis.close()
        
    async def set_cache(self, key: str, value: Any, expire_seconds: Optional[int] = None) -> bool:
        """Set a cache value with optional expiration"""
        try:
            serialized = json.dumps(value)
            if expire_seconds:
                await self.redis.setex(key, expire_seconds, serialized)
            else:
                await self.redis.set(key, serialized)
            return True
        except Exception as e:
            logger.error(f"Error setting cache for key {key}: {str(e)}")
            return False
            
    async def get_cache(self, key: str) -> Optional[Any]:
        """Get a cached value"""
        try:
            value = await self.redis.get(key)
            if value:
                return json.loads(value)
            return None
        except Exception as e:
            logger.error(f"Error getting cache for key {key}: {str(e)}")
            return None
            
    async def enqueue(self, queue_name: str, item: Any) -> bool:
        """Add an item to a queue"""
        try:
            serialized = json.dumps(item)
            await self.redis.rpush(queue_name, serialized)
            return True
        except Exception as e:
            logger.error(f"Error enqueueing item to {queue_name}: {str(e)}")
            return False
            
    async def dequeue(self, queue_name: str, timeout: int = 0) -> Optional[Any]:
        """Get and remove an item from a queue with optional timeout"""
        try:
            if timeout > 0:
                result = await self.redis.blpop(queue_name, timeout=timeout)
                if result:
                    return json.loads(result[1])
            else:
                result = await self.redis.lpop(queue_name)
                if result:
                    return json.loads(result)
            return None
        except Exception as e:
            logger.error(f"Error dequeuing item from {queue_name}: {str(e)}")
            return None
            
    async def get_queue_length(self, queue_name: str) -> int:
        """Get the current length of a queue"""
        try:
            return await self.redis.llen(queue_name)
        except Exception as e:
            logger.error(f"Error getting queue length for {queue_name}: {str(e)}")
            return 0
            
    async def clear_queue(self, queue_name: str) -> bool:
        """Clear all items from a queue"""
        try:
            await self.redis.delete(queue_name)
            return True
        except Exception as e:
            logger.error(f"Error clearing queue {queue_name}: {str(e)}")
            return False

    async def get_system_crawl_requests(self) -> List[Dict]:
        """Get pending system crawl requests from Redis"""
        try:
            # Get all requests from the system crawl channel
            requests = []
            async for message in self.redis.pubsub.listen():
                if message["type"] == "message" and message["channel"] == self.system_crawl_channel:
                    try:
                        request = json.loads(message["data"])
                        requests.append(request)
                    except json.JSONDecodeError:
                        logger.error(f"Invalid JSON in system crawl request: {message['data']}")
                        continue
            return requests
        except Exception as e:
            logger.error(f"Error getting system crawl requests: {e}")
            return []

    async def track_inquiry(self, inquiry_id: str, concept: str, weight: float, source: str = "system") -> bool:
        """Track an inquiry and its associated concept with weight"""
        try:
            inquiry_data = {
                "concept": concept,
                "weight": weight,
                "source": source,
                "timestamp": time.time(),
                "status": "pending"
            }
            await self.redis.hset(self.inquiry_tracking, inquiry_id, json.dumps(inquiry_data))
            # Add to crawl queue with weight-based priority
            await self.add_to_crawl_queue(concept, weight, source, inquiry_id)
            return True
        except Exception as e:
            logger.error(f"Error tracking inquiry: {e}")
            return False

    async def add_to_crawl_queue(self, concept: str, weight: float, source: str = "system", inquiry_id: Optional[str] = None) -> bool:
        """Add a concept to the crawl queue with weight-based priority"""
        try:
            # Calculate priority based on weight and source
            base_priority = weight
            if source == "system":
                base_priority *= 1.5  # Boost system inquiries
            
            request = {
                "concept": concept,
                "weight": weight,
                "priority": base_priority,
                "source": source,
                "inquiry_id": inquiry_id,
                "timestamp": time.time()
            }
            # Add to sorted set with priority as score
            await self.redis.zadd(self.crawl_queue, {json.dumps(request): base_priority})
            return True
        except Exception as e:
            logger.error(f"Error adding to crawl queue: {e}")
            return False

    async def store_vector(self, concept: str, vector: List[float], metadata: Dict) -> bool:
        """Store a vector with associated metadata in Redis and Qdrant"""
        try:
            vector_data = {
                "concept": concept,
                "vector": vector,
                "metadata": {
                    **metadata,
                    "timestamp": time.time(),
                    "format": "float32",
                    "dimensions": len(vector)
                }
            }
            # Store in Redis
            await self.redis.hset(
                self.vector_store,
                concept,
                json.dumps(vector_data)
            )
            # Store in Qdrant (sync call)
            self.qdrant.upsert_vectors(
                vectors=[vector],
                metadata=[metadata],
                ids=[concept]
            )
            return True
        except Exception as e:
            logger.error(f"Error storing vector: {e}")
            return False

    async def get_vector(self, concept: str) -> Optional[Dict]:
        """Retrieve a stored vector and its metadata"""
        try:
            data = await self.redis.hget(self.vector_store, concept)
            if data:
                return json.loads(data)
            return None
        except Exception as e:
            logger.error(f"Error retrieving vector: {e}")
            return None

    async def get_next_crawl_request(self) -> Optional[Dict]:
        """Get the highest priority crawl request from the queue"""
        try:
            # Get the highest priority request
            result = await self.redis.zpopmax(self.crawl_queue)
            if result:
                request = json.loads(result[0][0])
                # Update inquiry status if it exists
                if request.get("inquiry_id"):
                    await self.update_inquiry_status(request["inquiry_id"], "processing")
                return request
            return None
        except Exception as e:
            logger.error(f"Error getting next crawl request: {e}")
            return None

    async def update_inquiry_status(self, inquiry_id: str, status: str) -> bool:
        """Update the status of an inquiry"""
        try:
            data = await self.redis.hget(self.inquiry_tracking, inquiry_id)
            if data:
                inquiry_data = json.loads(data)
                inquiry_data["status"] = status
                await self.redis.hset(self.inquiry_tracking, inquiry_id, json.dumps(inquiry_data))
                return True
            return False
        except Exception as e:
            logger.error(f"Error updating inquiry status: {e}")
            return False

    async def add_to_dead_letter_queue(self, concept: str, error: str) -> None:
        """Add a failed crawl request to the dead letter queue"""
        try:
            await self.redis.hset(
                self.dead_letter_queue,
                concept,
                json.dumps({
                    "error": error,
                    "timestamp": time.time()
                })
            )
        except Exception as e:
            logger.error(f"Error adding to dead letter queue: {e}")

    async def get_queue_stats(self) -> Dict:
        """Get statistics about the crawl queues and inquiries"""
        try:
            return {
                "queue_size": await self.redis.zcard(self.crawl_queue),
                "dead_letter_size": await self.redis.hlen(self.dead_letter_queue),
                "vector_count": await self.redis.hlen(self.vector_store),
                "inquiry_count": await self.redis.hlen(self.inquiry_tracking),
                "priority_distribution": {
                    "high": await self.redis.zcount(self.crawl_queue, 0.7, 1.0),
                    "medium": await self.redis.zcount(self.crawl_queue, 0.3, 0.7),
                    "low": await self.redis.zcount(self.crawl_queue, 0, 0.3)
                },
                "source_distribution": {
                    "system": await self.redis.zcount(self.crawl_queue, 0, 1.0, "system"),
                    "graph": await self.redis.zcount(self.crawl_queue, 0, 1.0, "graph")
                }
            }
        except Exception as e:
            logger.error(f"Error getting queue stats: {e}")
            return {} 