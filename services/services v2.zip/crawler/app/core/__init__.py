"""
Core functionality for the Wikipedia Graph Crawler
""" 