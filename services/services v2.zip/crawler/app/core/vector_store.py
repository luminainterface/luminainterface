from typing import List, Dict, Optional
import numpy as np
from qdrant_client import QdrantClient
from qdrant_client.http import models
from qdrant_client.http.models import Distance, VectorParams
import logging

logger = logging.getLogger(__name__)

class VectorStore:
    def __init__(self, url: str, collection_name: str = "wiki_concepts"):
        self.client = QdrantClient(url=url)
        self.collection_name = collection_name
        
    def init_collection(self, vector_size: int = 384):
        """Initialize or recreate the collection with specified parameters"""
        try:
            # Check if collection exists
            collections = self.client.get_collections().collections
            exists = any(c.name == self.collection_name for c in collections)
            
            if exists:
                logger.info(f"Collection {self.collection_name} already exists")
                return
                
            # Create new collection
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(size=vector_size, distance=Distance.COSINE),
            )
            logger.info(f"Created new collection: {self.collection_name}")
        except Exception as e:
            logger.error(f"Error initializing collection: {str(e)}")
            raise

    def upsert_vectors(self, vectors: List[np.ndarray], metadata: List[Dict], ids: Optional[List[str]] = None):
        """Upsert vectors and their metadata to the collection"""
        try:
            points = []
            for i, (vector, meta) in enumerate(zip(vectors, metadata)):
                point_id = ids[i] if ids else str(i)
                points.append(
                    models.PointStruct(
                        id=point_id,
                        vector=vector.tolist(),
                        payload=meta
                    )
                )
                
            self.client.upsert(
                collection_name=self.collection_name,
                points=points
            )
            logger.info(f"Upserted {len(points)} vectors to collection {self.collection_name}")
        except Exception as e:
            logger.error(f"Error upserting vectors: {str(e)}")
            raise
            
    def search_similar(self, query_vector: np.ndarray, limit: int = 5) -> List[Dict]:
        """Search for similar vectors in the collection"""
        try:
            results = self.client.search(
                collection_name=self.collection_name,
                query_vector=query_vector.tolist(),
                limit=limit
            )
            return [
                {
                    "id": hit.id,
                    "score": hit.score,
                    "payload": hit.payload
                }
                for hit in results
            ]
        except Exception as e:
            logger.error(f"Error searching vectors: {str(e)}")
            return [] 