"""
API endpoints for the Wikipedia Graph Crawler
""" 