# Wikipedia Crawler Service

A service for crawling Wikipedia pages and building a knowledge graph. The service integrates with:
- Qdrant for vector storage
- Redis for caching and queuing
- Graph API for relationship management
- Concept Dictionary for concept storage

## Features

- Crawl Wikipedia pages starting from a given title
- Extract and store page content, summaries, and relationships
- Generate and store embeddings for semantic search
- Cache processed pages to avoid redundant processing
- Build a knowledge graph of page relationships
- Search for similar concepts using vector similarity

## API Endpoints

### POST /api/v1/crawl
Start crawling from a given Wikipedia page.

Request body:
```json
{
    "start_title": "string",
    "max_depth": 2,
    "max_links_per_page": 10
}
```

### GET /api/v1/search
Search for similar concepts.

Query parameters:
- `query`: Search query string
- `limit`: Maximum number of results (default: 5)

### GET /api/v1/health
Health check endpoint.

## Environment Variables

- `REDIS_URL`: Redis connection URL (default: redis://localhost:6379)
- `QDRANT_URL`: Qdrant connection URL (default: http://localhost:6333)
- `GRAPH_API_URL`: Graph API URL (default: http://localhost:8200)
- `CONCEPT_DICT_URL`: Concept Dictionary URL (default: http://localhost:8000)
- `EMBEDDING_MODEL`: Sentence transformer model name (default: all-MiniLM-L6-v2)
- `WIKI_SEARCH_DEPTH`: Maximum crawl depth (default: 2)
- `WIKI_MAX_RESULTS`: Maximum links per page (default: 10)

## Development

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the service:
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8400
```

## Docker

Build and run with Docker:
```bash
docker build -t crawler .
docker run -p 8400:8400 crawler
```

## Architecture

The service is built with a modular architecture:

- `core/`: Core components
  - `wiki_client.py`: Wikipedia API client
  - `vector_store.py`: Qdrant vector store client
  - `graph_client.py`: Graph API client
  - `concept_client.py`: Concept Dictionary client
  - `redis_client.py`: Redis client
  - `crawler.py`: Main crawler logic

- `api/`: API endpoints
  - `router.py`: FastAPI router

- `main.py`: Application entry point 