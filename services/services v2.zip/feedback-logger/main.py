from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import redis
import json
import os
from typing import List, Optional, Dict
import logging
from prometheus_client import Counter, Histogram
import time
from datetime import datetime

# Initialize FastAPI app
app = FastAPI(title="Feedback Logger Service")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Redis client
redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
redis_client = redis.from_url(redis_url)

# Prometheus metrics
feedback_entries = Counter('feedback_entries_total', 'Total number of feedback entries')
feedback_latency = Histogram('feedback_latency_seconds', 'Time spent processing feedback')
feedback_ratings = Histogram('feedback_ratings', 'Distribution of feedback ratings')

class Feedback(BaseModel):
    query: str
    response: str
    rating: float  # 0.0 to 1.0
    feedback: Optional[str] = None
    concepts_used: Optional[List[str]] = None
    session_id: Optional[str] = None

@app.get("/health")
async def health_check():
    try:
        redis_client.ping()
        return {"status": "healthy", "redis": "connected"}
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        raise HTTPException(status_code=503, detail="Service unhealthy")

@app.post("/feedback")
async def log_feedback(feedback: Feedback):
    with feedback_latency.time():
        feedback_entries.inc()
        feedback_ratings.observe(feedback.rating)
        try:
            # Create feedback entry with timestamp
            entry = {
                "timestamp": datetime.utcnow().isoformat(),
                "query": feedback.query,
                "response": feedback.response,
                "rating": feedback.rating,
                "feedback": feedback.feedback,
                "concepts_used": feedback.concepts_used,
                "session_id": feedback.session_id
            }
            
            # Store in Redis with TTL of 30 days
            key = f"feedback:{datetime.utcnow().timestamp()}"
            redis_client.setex(key, 30 * 24 * 60 * 60, json.dumps(entry))
            
            # Add to feedback list for analysis
            redis_client.lpush("feedback:list", key)
            
            return {"status": "success", "feedback_id": key}
        except Exception as e:
            logger.error(f"Error logging feedback: {str(e)}")
            raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/feedback")
async def get_feedback(session_id: Optional[str] = None, limit: int = 100):
    try:
        # Get feedback keys
        if session_id:
            pattern = f"feedback:*"
            keys = []
            for key in redis_client.scan_iter(match=pattern):
                data = json.loads(redis_client.get(key))
                if data.get("session_id") == session_id:
                    keys.append(key)
        else:
            keys = redis_client.lrange("feedback:list", 0, limit - 1)
        
        # Get feedback entries
        feedback_entries = []
        for key in keys:
            data = redis_client.get(key)
            if data:
                feedback_entries.append(json.loads(data))
        
        return feedback_entries
    except Exception as e:
        logger.error(f"Error retrieving feedback: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8500) 