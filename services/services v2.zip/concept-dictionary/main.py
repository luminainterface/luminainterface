from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, List, Optional
import redis
import json
import os
import logging
from prometheus_client import Counter, Histogram
from prometheus_fastapi_instrumentator import Instrumentator
import numpy as np
from datetime import datetime
import httpx
from qdrant_client import QdrantClient

# Environment variables
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
QDRANT_URL = os.getenv("QDRANT_URL", "http://qdrant:6333")

# Initialize FastAPI app
app = FastAPI(title="Concept Dictionary")
Instrumentator().instrument(app).expose(app)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("concept-dictionary")

# Initialize Redis client
redis_client = redis.Redis.from_url(REDIS_URL, decode_responses=True)

# Initialize Qdrant client
qdrant_client = QdrantClient(url=QDRANT_URL)

# Initialize metrics
CONCEPT_UPDATES = Counter(
    'concept_dictionary_updates_total',
    'Number of concept updates'
)

CONCEPT_RETRIEVALS = Counter(
    'concept_dictionary_retrievals_total',
    'Number of concept retrievals'
)

RETRIEVAL_LATENCY = Histogram(
    'concept_dictionary_retrieval_latency_seconds',
    'Time spent retrieving concepts'
)

class Concept(BaseModel):
    term: str
    definition: str
    embedding: Optional[List[float]] = None
    metadata: Optional[Dict] = None
    last_updated: Optional[str] = None

@app.get("/health")
async def health():
    """Health check endpoint"""
    try:
        # Check Redis connection
        redis_client.ping()
        
        # Check Qdrant connection
        qdrant_client.get_collections()
        
        return {
            "status": "healthy",
            "dependencies": {
                "redis": "connected",
                "qdrant": "connected"
            }
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }

@app.get("/concepts")
async def get_concepts() -> List[Dict]:
    """Get all concepts"""
    with RETRIEVAL_LATENCY.time():
        try:
            concepts = []
            for key in redis_client.scan_iter("concept:*"):
                concept_data = redis_client.get(key)
                if concept_data:
                    concepts.append(json.loads(concept_data))
            CONCEPT_RETRIEVALS.inc()
            return concepts
        except Exception as e:
            logger.error(f"Error retrieving concepts: {e}")
            raise HTTPException(status_code=500, detail=str(e))

@app.get("/concepts/{term}")
async def get_concept(term: str) -> Dict:
    """Get a specific concept"""
    with RETRIEVAL_LATENCY.time():
        try:
            concept_data = redis_client.get(f"concept:{term}")
            if not concept_data:
                raise HTTPException(status_code=404, detail="Concept not found")
            CONCEPT_RETRIEVALS.inc()
            return json.loads(concept_data)
        except Exception as e:
            logger.error(f"Error retrieving concept {term}: {e}")
            raise HTTPException(status_code=500, detail=str(e))

@app.put("/concepts/{term}")
async def update_concept(term: str, concept: Concept):
    """Update or create a concept"""
    try:
        # Update timestamp
        concept.last_updated = datetime.utcnow().isoformat()
        
        # Store in Redis
        redis_client.set(
            f"concept:{term}",
            json.dumps(concept.dict())
        )
        
        # If embedding exists, store in Qdrant
        if concept.embedding:
            qdrant_client.upsert(
                collection_name="concepts",
                points=[{
                    "id": term,
                    "vector": concept.embedding,
                    "payload": {
                        "term": term,
                        "definition": concept.definition,
                        "metadata": concept.metadata or {}
                    }
                }]
            )
        
        CONCEPT_UPDATES.inc()
        return {"status": "success", "message": f"Concept {term} updated"}
    except Exception as e:
        logger.error(f"Error updating concept {term}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/concepts/{term}")
async def delete_concept(term: str):
    """Delete a concept"""
    try:
        # Remove from Redis
        if redis_client.delete(f"concept:{term}") == 0:
            raise HTTPException(status_code=404, detail="Concept not found")
        
        # Remove from Qdrant
        try:
            qdrant_client.delete(
                collection_name="concepts",
                points_selector={"ids": [term]}
            )
        except Exception as e:
            logger.warning(f"Error removing concept from Qdrant: {e}")
        
        return {"status": "success", "message": f"Concept {term} deleted"}
    except Exception as e:
        logger.error(f"Error deleting concept {term}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/concepts/reembed")
async def reembed_concepts():
    """Re-embed all concepts and update Qdrant"""
    try:
        concepts = await get_concepts()
        for concept in concepts:
            if "embedding" in concept:
                try:
                    qdrant_client.upsert(
                        collection_name="concepts",
                        points=[{
                            "id": concept["term"],
                            "vector": concept["embedding"],
                            "payload": {
                                "term": concept["term"],
                                "definition": concept["definition"],
                                "metadata": concept.get("metadata", {})
                            }
                        }]
                    )
                except Exception as e:
                    logger.error(f"Error re-embedding concept {concept['term']}: {e}")
        
        return {"status": "success", "message": f"Re-embedded {len(concepts)} concepts"}
    except Exception as e:
        logger.error(f"Error during re-embedding: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 